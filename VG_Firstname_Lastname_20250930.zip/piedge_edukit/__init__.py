# SPDX-License-Identifier: MIT
# PiEdge EduKit - Edge ML Education Kit for Raspberry Pi
__version__ = "0.1.0"
