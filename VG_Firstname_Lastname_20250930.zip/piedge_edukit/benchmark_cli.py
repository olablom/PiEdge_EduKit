#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
# benchmark_cli.py - Command line interface for benchmarking

from piedge_edukit.benchmark import main

if __name__ == "__main__":
    main()
