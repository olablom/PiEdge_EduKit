#!/usr/bin/env bash
# filename: scripts/setup_venv.sh
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3.12}"

echo "[setup] Creating .venv with ${PYTHON_BIN}"
$PYTHON_BIN -V

$PYTHON_BIN -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate

python -m pip install --upgrade pip
# Prefer pip; uv is allowed but not required by the spec
pip install -r requirements.txt

echo "[setup] .venv ready. To activate: source .venv/bin/activate"
